from graph import Graph

def cycle_detection(graph):
    node = graph.nodes[0]
    v=[]
    stack = [node]
    for i in range(len(node.edges)):
        pass
