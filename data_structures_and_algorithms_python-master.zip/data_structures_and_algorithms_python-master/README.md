# data_structures_and_algorithms_python
This is a practice repository for data structures and algorithms, implemented in python.
